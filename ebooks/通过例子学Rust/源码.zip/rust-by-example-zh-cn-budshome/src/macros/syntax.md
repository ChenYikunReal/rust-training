# 语法

在下面的小节中，我们将展示如何在 Rust 中定义宏。基本的概念有三个：

- [模式与指示符][designators]
- [重载][overloading]
- [重复][repetition]

[designators]: designators.md
[overloading]: overload.md
[repetition]: repeat.md