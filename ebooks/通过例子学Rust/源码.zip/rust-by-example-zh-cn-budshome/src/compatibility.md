# 兼容性

Rust 语言正在快速发展，因此尽管努力确保尽可能向前兼容，但仍可能出现某些兼容性问题。

* [原始标识符](compatibility/raw_identifiers.md)
